from django.db import models

# Create your models here.

class recipe(models.Model):
    Name = models.CharField(max_length=50)
    image = models.ImageField(upload_to='photos/')
    ingredients = models.TextField(help_text=" ")
    steps = models.TextField(help_text=" ")

def _str_(self):
    return self.name