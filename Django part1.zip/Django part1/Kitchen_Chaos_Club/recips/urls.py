from django.urls import path 
from . import views

urlpatterns = [
    path('', views.index, name='home'),
    path('appetizer', views.appetizer, name='appetizer'),
    path('Desserts', views.Desserts, name='Desserts'),
    path('maincourse', views.maincourse, name='maincourse'),
    path('login-signup', views.login_signup, name='login_signup'),
    path('favorites', views.favorites, name='favorites'),
    path('edit', views.edits, name='edit'),
    path('Addrecipes', views.Addrecipes, name='Addrecipes'),
]
        