from django.shortcuts import render, redirect


# Create your views here.

def index(request):
    return render(request, 'index.html')

def appetizer(request):
    return render(request, 'appetizer.html')

def Desserts(request):
    return render(request, 'Desserts.html')

def maincourse(request):
    return render(request, 'maincourse.html')

def login_signup(request):          
    return render(request, 'login_signup.html')

def favorites(request):
    return render(request, 'favorites.html')

def edits(request):
    return render(request, 'edit.html')

def Addrecipes(request):
    return render(request, 'Addrecipes.html')


